import { NextResponse } from "next/server";
import Stripe from "stripe";

// Nécessaire pour que Stripe puisse vérifier la signature sur le corps brut
export const runtime = "nodejs";

export async function POST(req: Request) {
  const secretKey = process.env.STRIPE_SECRET_KEY;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!secretKey || !webhookSecret) {
    console.error("Webhook: configuration manquante.");
    return NextResponse.json({ error: "Configuration manquante." }, { status: 500 });
  }

  const stripe = new Stripe(secretKey);
  const signature = req.headers.get("stripe-signature");
  const body = await req.text();

  let event: Stripe.Event;

  try {
    if (!signature) throw new Error("Signature manquante.");
    event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
  } catch (err) {
    console.error("Signature webhook invalide:", err);
    return NextResponse.json({ error: "Signature invalide." }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    // C'est ICI, côté serveur et vérifié par Stripe, qu'on sait qu'un paiement
    // est réellement confirmé — jamais en se fiant à la redirection seule.
    // Pour l'instant (étape 0, pas de base de données), on journalise
    // l'évènement : il apparaît dans Vercel > Logs, et Stripe t'envoie
    // aussi un email de confirmation si tu l'as activé dans ses réglages.
    console.log("Paiement confirmé:", {
      sessionId: session.id,
      email: session.customer_details?.email,
      montant: session.amount_total,
    });
  }

  return NextResponse.json({ received: true });
}
